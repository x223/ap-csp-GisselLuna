var fillcolor = 'red'

function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background(0);
  fill('pink');
  rect(110,90,120,230);
  fill('white')	
  ellipse(170,150,50,50);
  ellipse(170,210,50,50);
  ellipse(170,270,50,50);
  
if (mouseX > = windowwidth /2) {
  fillcolor = ('red')
  
  
}
}